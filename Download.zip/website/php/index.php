<?php
// Ten plik jest obecnie pusty.
// Możesz go użyć w przyszłości do obsługi logiki po stronie serwera,
// na przykład do obsługi formularzy, logowania użytkowników,
// łączenia z bazą danych itp.

// Przykład:
// header('Content-Type: application/json');
// echo json_encode(['message' => 'Witaj z serwera PHP!']);
?>

