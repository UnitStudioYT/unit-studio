// Czekamy, aż cały dokument HTML zostanie wczytany
document.addEventListener('DOMContentLoaded', () => {

    // --- OBSŁUGA MENU W TRYBIE POZIOMYM (LANDSCAPE) ---
    const menuToggleLandscape = document.getElementById('menu-toggle-landscape');
    const menuLandscape = document.getElementById('menu-landscape');

    if (menuToggleLandscape && menuLandscape) {
        menuToggleLandscape.addEventListener('click', (event) => {
            // Zapobiegamy propagacji, aby kliknięcie nie zamknęło menu od razu
            event.stopPropagation(); 
            menuLandscape.classList.toggle('open');
        });
    }

    // Zamykanie menu landscape po kliknięciu gdziekolwiek na stronie
    document.addEventListener('click', () => {
        if (menuLandscape && menuLandscape.classList.contains('open')) {
            menuLandscape.classList.remove('open');
        }
    });

    // --- OBSŁUGA MENU W TRYBIE PIONOWYM (PORTRAIT) ---
    const menuTogglePortrait = document.getElementById('menu-toggle-portrait');
    const menuClosePortrait = document.getElementById('menu-close-portrait');
    const menuWrapper = document.getElementById('menu-portrait-wrapper');
    const moreBtn = document.getElementById('menu-more-btn');
    const backBtn = document.getElementById('menu-back-btn');

    // Sprawdzamy, czy wszystkie elementy istnieją
    if (menuTogglePortrait && menuClosePortrait && menuWrapper && moreBtn && backBtn) {
        
        // Otwieranie menu
        menuTogglePortrait.addEventListener('click', () => {
            menuWrapper.classList.add('open');
        });

        // Zamykanie menu (główny przycisk X)
        menuClosePortrait.addEventListener('click', () => {
            menuWrapper.classList.remove('open');
            // Jeśli podmenu było otwarte, resetujemy je
            menuWrapper.classList.remove('show-more'); 
        });

        // Zamykanie menu po kliknięciu w tło
        menuWrapper.addEventListener('click', (event) => {
            // Zamykamy tylko, jeśli kliknięto bezpośrednio w tło (wrapper)
            if (event.target === menuWrapper) {
                menuWrapper.classList.remove('open');
                menuWrapper.classList.remove('show-more');
            }
        });

        // Przejście do podmenu "More"
        moreBtn.addEventListener('click', () => {
            menuWrapper.classList.add('show-more');
        });

        // Powrót z podmenu "More" do menu głównego
        backBtn.addEventListener('click', () => {
            menuWrapper.classList.remove('show-more');
        });
    }
});

