import os
import subprocess
from colorama import Fore, Style, init

init(autoreset=True)

is_admin = os.getuid() == 0 if os.name != 'nt' else False

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def prompt():
    while True:
        clear()
        print()

        if not is_admin:
            print(f"[{Fore.RED}  /Z\\{Style.RESET_ALL}]         {Fore.GREEN}SUROOT OS{Style.RESET_ALL}")
            print(f"               {Fore.LIGHTBLACK_EX}Powered by UNIT Studio")
            print(f"               {Fore.LIGHTBLACK_EX}Version: 0.2.1 | Updated: 2025-05-31\n")
        else:
            print("[ /Z\\ ]         SUROOT OS")
            print("               Powered by UNIT Studio")
            print("               Version: 0.2.1 | Updated: 2025-05-31\n")

        command = input(f"{os.getlogin()}@suroot:~# ").strip().lower()

        if command == "exit":
            break

        elif command == "help":
            print("\ndate - Show actual date")
            print("ip - Show IP config")
            print("ip -a - Advanced IP info")
            print("whoami - Show current user")
            print("mkdir [foldername] - Make dir")
            print("cd [folder] - Change dir")
            print("cd ~ - Go to home dir")
            print("ls - List files")
            print("ls -la - List all including hidden")
            print("su - Switch to root")
            print("tree - Show file tree with system log")
            print("exit - Quit SUROOT terminal")
            input("\nPress Enter to continue...")

        elif command == "date":
            os.system("date /t & time /t" if os.name == 'nt' else "date")
            input("\nPress Enter to continue...")

        elif command == "whoami":
            print("\nroot" if is_admin else os.getlogin())
            input("\nPress Enter to continue...")

        elif command == "ip":
            os.system("ipconfig /all" if os.name == 'nt' else "ifconfig")
            input("\nPress Enter to continue...")

        elif command == "ip -a":
            if os.name == 'nt':
                os.system('ipconfig | findstr "IPv4 IPv6 DNS"')
            else:
                os.system("ifconfig | grep 'inet\\|dns'")
            input("\nPress Enter to continue...")

        elif command.startswith("mkdir "):
            folder = command[6:].strip()
            os.makedirs(folder, exist_ok=True)
            print(f'Folder "{folder}" created.')
            input("\nPress Enter to continue...")

        elif command == "cd ~":
            os.chdir(os.path.expanduser("~"))
            print(f"Now in {os.getcwd()}")
            input("\nPress Enter to continue...")

        elif command.startswith("cd "):
            directory = command[3:].strip()
            try:
                os.chdir(directory)
                print(f"Now in {os.getcwd()}")
            except FileNotFoundError:
                print("Folder not found.")
            input("\nPress Enter to continue...")

        elif command == "ls":
            print("\n".join(os.listdir()))
            input("\nPress Enter to continue...")

        elif command == "ls -la":
            for file in os.listdir():
                print(file)
            input("\nPress Enter to continue...")

        elif command == "su":
            print("\nSwitched to root (simulation).")
            global is_admin
            is_admin = True
            input("\nPress Enter to continue...")

        elif command == "tree":
            os.system("tree" if os.name == 'nt' else "tree .")
            print(f"\n[System Log]")
            print(f"RAM: {Fore.GREEN}{os.urandom(1)[0]}{Style.RESET_ALL} MB Used")
            print(f"Bluetooth: not detected")
            print(f"Disk: {Fore.GREEN}OK{Style.RESET_ALL}")
            print(f"CPU Temp: {Fore.YELLOW}{os.urandom(1)[0]}{Style.RESET_ALL} °C")
            print(f"Net: {Fore.GREEN}Connected{Style.RESET_ALL}")
            input("\nPress Enter to continue...")

        else:
            print("\nUnknown command.")
            input("\nPress Enter to continue...")

if __name__ == "__main__":
    prompt()