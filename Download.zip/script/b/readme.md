pip install colorama
pyinstaller --one-dir --console suroot.py